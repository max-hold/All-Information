"use strict";

// ═══════════════════════════════════════════════════════════════════════════
// KIOSK GUARD — background.js
// Handles: URL capture per tab | Download blocking | Download size limit
// ═══════════════════════════════════════════════════════════════════════════


// ───────────────────────────────────────────────────────────────────────────
// ★ CONFIGURATION BLOCK — edit only this section
// ───────────────────────────────────────────────────────────────────────────

// DOWNLOAD TOGGLE
// TO DISABLE all downloads → set to false (default)
// TO ENABLE  all downloads → set to true
const DOWNLOADS_ENABLED = false;                          // ← TOGGLE THIS LINE

// DOWNLOAD SIZE LIMIT (only active when DOWNLOADS_ENABLED = true)
// Unit: gigabytes. Change the number to set a different cap.
const MAX_DOWNLOAD_SIZE_GB    = 5;                        // ← CHANGE THIS VALUE
const MAX_DOWNLOAD_SIZE_BYTES = MAX_DOWNLOAD_SIZE_GB * 1024 * 1024 * 1024;

// HOST LOG ENDPOINT
// Where captured URLs and events are sent (your host controller).
// Leave as-is until the host service is ready — failed sends are silently ignored.
const LOG_ENDPOINT    = "http://127.0.0.1:8888/log";     // ← SET YOUR ENDPOINT

// LOCAL STORAGE LOG
// Always keeps a local copy inside the extension storage (independent of endpoint).
const LOG_TO_STORAGE  = true;

// MAX LOCAL LOG ENTRIES (prevents unbounded memory growth)
const MAX_URL_LOG_ENTRIES   = 10000;
const MAX_EVENT_LOG_ENTRIES = 5000;

// ───────────────────────────────────────────────────────────────────────────


// ═══════════════════════════════════════════════════════════════════════════
// URL CAPTURE
// Captures every URL the user navigates to, across all tabs.
// Events:
//   tab_created   — a new tab was opened
//   tab_updated   — address bar URL changed (typed, clicked link, redirect)
//   tab_activated — user switched to an existing tab
// ═══════════════════════════════════════════════════════════════════════════

function captureURL(tabId, url, event) {
  // Skip internal browser pages — they are not user-navigated URLs
  if (!url) return;
  if (url.startsWith("about:"))          return;
  if (url.startsWith("moz-extension:")) return;
  if (url.startsWith("chrome:"))        return;

  const entry = {
    timestamp : new Date().toISOString(),
    type      : "url",
    event,        // tab_created | tab_updated | tab_activated
    tabId,
    url,
  };

  saveToStorage("urlLog", entry, MAX_URL_LOG_ENTRIES);
  sendToHost(entry);

  console.log(`[KIOSK GUARD] URL | ${event} | tab ${tabId} | ${url}`);
}

// New tab opened
browser.tabs.onCreated.addListener((tab) => {
  if (tab.url) captureURL(tab.id, tab.url, "tab_created");
});

// URL in address bar changed (navigation, redirect, history push)
browser.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.url) captureURL(tabId, changeInfo.url, "tab_updated");
});

// User switched to a different tab
browser.tabs.onActivated.addListener(({ tabId }) => {
  browser.tabs.get(tabId).then((tab) => {
    if (tab.url) captureURL(tab.id, tab.url, "tab_activated");
  }).catch(() => {});
});


// ═══════════════════════════════════════════════════════════════════════════
// DOWNLOAD CONTROL
// Two independent checks run on every download attempt:
//   1. Global toggle  — if DOWNLOADS_ENABLED = false, cancel everything.
//   2. Size limit     — if file size > MAX_DOWNLOAD_SIZE_BYTES, cancel.
// ═══════════════════════════════════════════════════════════════════════════

browser.downloads.onCreated.addListener((item) => {

  // ── Check 1: Global download toggle ─────────────────────────────────────
  if (!DOWNLOADS_ENABLED) {
    cancelDownload(item.id);
    logEvent("download_blocked_disabled", {
      url      : item.url,
      filename : item.filename,
      reason   : "Downloads are disabled by policy.",
    });
    console.warn(`[KIOSK GUARD] Download BLOCKED (disabled): ${item.url}`);
    return; // No further checks needed
  }

  // ── Check 2: File size limit ─────────────────────────────────────────────
  // totalBytes is -1 when the server did not send a Content-Length header.
  // In that case we cannot know the size upfront and allow it through.
  if (item.totalBytes > 0 && item.totalBytes > MAX_DOWNLOAD_SIZE_BYTES) {
    cancelDownload(item.id);

    const actualMB = (item.totalBytes / (1024 * 1024)).toFixed(1);
    const limitGB  = MAX_DOWNLOAD_SIZE_GB;

    logEvent("download_blocked_size", {
      url      : item.url,
      filename : item.filename,
      actualMB,
      limitGB,
      reason   : `File size ${actualMB} MB exceeds the ${limitGB} GB limit.`,
    });
    console.warn(`[KIOSK GUARD] Download BLOCKED (${actualMB} MB > ${limitGB} GB): ${item.url}`);
  }

  // If both checks pass, download proceeds normally.
});

// Cancel a download and erase it from the download manager UI
function cancelDownload(downloadId) {
  browser.downloads.cancel(downloadId)
    .then(() => browser.downloads.erase({ id: downloadId }))
    .catch(() => {});
}


// ═══════════════════════════════════════════════════════════════════════════
// STORAGE HELPER
// Appends an entry to a named log array in extension local storage.
// Enforces a maximum entry count to cap memory usage.
// ═══════════════════════════════════════════════════════════════════════════

function saveToStorage(key, entry, maxEntries) {
  if (!LOG_TO_STORAGE) return;

  browser.storage.local.get(key).then((result) => {
    const log = result[key] || [];
    log.push(entry);

    // Trim oldest entries if over the cap
    if (log.length > maxEntries) {
      log.splice(0, log.length - maxEntries);
    }

    browser.storage.local.set({ [key]: log });
  }).catch(() => {});
}


// ═══════════════════════════════════════════════════════════════════════════
// EVENT LOGGER
// Logs non-URL events (blocked downloads, errors, etc.)
// ═══════════════════════════════════════════════════════════════════════════

function logEvent(type, data) {
  const entry = {
    timestamp : new Date().toISOString(),
    type,
    ...data,
  };

  saveToStorage("eventLog", entry, MAX_EVENT_LOG_ENTRIES);
  sendToHost(entry);
}


// ═══════════════════════════════════════════════════════════════════════════
// HOST SENDER
// Posts a log entry to the host controller endpoint.
// Failures are silently ignored — the local storage copy is always kept.
// ═══════════════════════════════════════════════════════════════════════════

function sendToHost(entry) {
  fetch(LOG_ENDPOINT, {
    method  : "POST",
    headers : { "Content-Type": "application/json" },
    body    : JSON.stringify(entry),
  }).catch(() => {
    // Host not running yet — ignore silently, local log is the fallback
  });
}
