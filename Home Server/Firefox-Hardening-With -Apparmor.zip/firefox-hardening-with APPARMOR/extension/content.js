"use strict";

// ═══════════════════════════════════════════════════════════════════════════
// KIOSK GUARD — content.js
// Blocks keyboard shortcuts on every web page and every iframe.
// Runs at document_start before any page script executes.
// ═══════════════════════════════════════════════════════════════════════════


// ───────────────────────────────────────────────────────────────────────────
// ★ SHORTCUT CONFIGURATION — edit this section to allow specific shortcuts
// ───────────────────────────────────────────────────────────────────────────

// Ctrl / Cmd key combos that ARE allowed to pass through.
// Everything else with Ctrl is blocked.
// Example: ["a", "c", "v", "x"] allows select-all, copy, paste, cut.
const ALLOWED_CTRL_KEYS = ["a", "c", "v", "x"];         // ← EDIT ALLOWED CTRL COMBOS

// Set to true to also block Ctrl+A, Ctrl+C, Ctrl+V, Ctrl+X (copy/paste).
// Warning: blocking these may frustrate users who need to copy text.
const BLOCK_ALL_CTRL = false;                             // ← SET true TO BLOCK COPY/PASTE TOO

// Function keys to block (F1–F12).
// Remove any key from this list to allow it through.
const BLOCKED_FUNCTION_KEYS = [
  "F1","F2","F3","F4","F5","F6",
  "F7","F8","F9","F10","F11","F12"
];

// Block the Escape key (prevents dismissing dialogs or exiting fullscreen).
const BLOCK_ESCAPE = true;

// ───────────────────────────────────────────────────────────────────────────


// ═══════════════════════════════════════════════════════════════════════════
// EVENT LISTENERS
// Capture at the window level with useCapture=true so we intercept
// the event BEFORE the page's own event handlers can respond.
// ═══════════════════════════════════════════════════════════════════════════

window.addEventListener("keydown", handleKey, true);
window.addEventListener("keyup",   handleKey, true);


function handleKey(event) {
  const ctrl  = event.ctrlKey || event.metaKey;
  const alt   = event.altKey;
  const key   = event.key;
  const keyLo = key.toLowerCase();

  // ── Rule 1: Block all Alt+? combinations ──────────────────────────────
  // Alt+F4 (close window), Alt+Left/Right (history navigation), Alt+D (address bar), etc.
  if (alt) {
    suppress(event);
    return;
  }

  // ── Rule 2: Ctrl / Cmd key combinations ───────────────────────────────
  if (ctrl) {
    if (BLOCK_ALL_CTRL) {
      // Block every single Ctrl combination
      suppress(event);
      return;
    }
    // Allow only whitelisted Ctrl combos; block everything else
    if (!ALLOWED_CTRL_KEYS.includes(keyLo)) {
      suppress(event);
      return;
    }
  }

  // ── Rule 3: Function keys ─────────────────────────────────────────────
  if (BLOCKED_FUNCTION_KEYS.includes(key)) {
    suppress(event);
    return;
  }

  // ── Rule 4: Escape key ────────────────────────────────────────────────
  if (BLOCK_ESCAPE && key === "Escape") {
    suppress(event);
    return;
  }
}


// Cancels the event and stops it from reaching the page
function suppress(event) {
  event.preventDefault();
  event.stopPropagation();
  event.stopImmediatePropagation();
}


// ═══════════════════════════════════════════════════════════════════════════
// NOTE ON BROWSER CHROME SHORTCUTS
// ─────────────────────────────────────────────────────────────────────────
// This content script blocks shortcuts AT THE PAGE LEVEL.
// Shortcuts handled directly by the Firefox browser chrome (e.g. Ctrl+T for
// new tab, Ctrl+W for close tab, Ctrl+L for address bar focus) are NOT
// reachable from a content script. Those are handled by:
//   - policies.json (DisableDeveloperTools blocks Ctrl+Shift+I, F12)
//   - Firefox kiosk mode flag (--kiosk) blocks Ctrl+W, Ctrl+Q
//   - AppArmor profile prevents spawning new processes
// Together all three layers cover the full shortcut surface.
// ═══════════════════════════════════════════════════════════════════════════
