# Check if your kernel has AppArmor compiled in
grep CONFIG_SECURITY_APPARMOR /boot/config-$(uname -r)

# Check if securityfs is mounted
mount | grep security

# Check kernel security directory
ls /sys/kernel/security/



# Check your current bootloader config
cat /etc/update-extlinux.conf
# Open the extlinux config (Alpine's default bootloader)
nano /etc/update-extlinux.conf

# Before:
default_kernel_opts="quiet rootfstype=ext4"

# After:
default_kernel_opts="quiet rootfstype=ext4 security=apparmor"


update-extlinux
reboot




# This should now show the apparmor directory
ls /sys/kernel/security/

# Should return: apparmor

# Then check AppArmor is running
cat /sys/kernel/security/apparmor/profiles



apparmor_parser -r /etc/apparmor.d/usr.bin.firefox
aa-enforce /etc/apparmor.d/usr.bin.firefox
rc-update add apparmor boot


# Step 1 — install base abstractions (fixes tunables/global)
doas apk add apparmor-profiles

# Step 2 — copy updated profile (no more missing abstractions)
doas cp usr.bin.firefox /etc/apparmor.d/usr.bin.firefox

# Step 3 — load and enforce
doas apparmor_parser -r /etc/apparmor.d/usr.bin.firefox
doas aa-enforce /etc/apparmor.d/usr.bin.firefox

# Step 4 — enable on boot
doas rc-update add apparmor boot
