#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════
# install.sh — Firefox Hardening Installer
# Run this INSIDE the Alpine VM as root after Firefox is installed.
#
# What this script does:
#   1. Installs policies.json       → enterprise policy locks
#   2. Installs autoconfig.js       → points Firefox to firefox.cfg
#   3. Installs firefox.cfg         → lockprefs + download toggle
#   4. Packages the extension       → kiosk-guard.xpi
#   5. Installs AppArmor profile    → filesystem + process restrictions
# ═══════════════════════════════════════════════════════════════════════════

set -e  # Exit immediately on any error

# ─────────────────────────────────────────────────────────────────────────
# CONFIG — adjust these paths if your Firefox install is in a different location
# ─────────────────────────────────────────────────────────────────────────
FIREFOX_BIN="/usr/bin/firefox"
FIREFOX_LIB="/usr/lib/firefox"
POLICY_DIR="$FIREFOX_LIB/distribution"
EXTENSION_DEST="/opt/kiosk-guard"
APPARMOR_DIR="/etc/apparmor.d"

# ─────────────────────────────────────────────────────────────────────────
# CHECKS
# ─────────────────────────────────────────────────────────────────────────
echo "──────────────────────────────────────────"
echo " Firefox Hardening Installer"
echo "──────────────────────────────────────────"

if [ "$(id -u)" -ne 0 ]; then
  echo "✖ This script must be run as root. Use: sudo ./install.sh"
  exit 1
fi

if [ ! -f "$FIREFOX_BIN" ]; then
  echo "✖ Firefox not found at $FIREFOX_BIN"
  echo "  Install it first: apk add firefox"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "✔ Running from: $SCRIPT_DIR"
echo "✔ Firefox found at: $FIREFOX_BIN"
echo ""

# ─────────────────────────────────────────────────────────────────────────
# STEP 1: policies.json
# ─────────────────────────────────────────────────────────────────────────
echo "[1/5] Installing policies.json..."
mkdir -p "$POLICY_DIR"
cp "$SCRIPT_DIR/config/policies.json" "$POLICY_DIR/policies.json"
chmod 644 "$POLICY_DIR/policies.json"
echo "      → $POLICY_DIR/policies.json ✔"

# ─────────────────────────────────────────────────────────────────────────
# STEP 2: autoconfig.js (pointer file)
# ─────────────────────────────────────────────────────────────────────────
echo "[2/5] Installing autoconfig.js..."
mkdir -p "$FIREFOX_LIB/defaults/pref"
cp "$SCRIPT_DIR/config/autoconfig.js" "$FIREFOX_LIB/defaults/pref/autoconfig.js"
chmod 644 "$FIREFOX_LIB/defaults/pref/autoconfig.js"
echo "      → $FIREFOX_LIB/defaults/pref/autoconfig.js ✔"

# ─────────────────────────────────────────────────────────────────────────
# STEP 3: firefox.cfg (lockprefs + download toggle)
# ─────────────────────────────────────────────────────────────────────────
echo "[3/5] Installing firefox.cfg..."
cp "$SCRIPT_DIR/config/firefox.cfg" "$FIREFOX_LIB/firefox.cfg"
chmod 644 "$FIREFOX_LIB/firefox.cfg"
echo "      → $FIREFOX_LIB/firefox.cfg ✔"

# ─────────────────────────────────────────────────────────────────────────
# STEP 4: Package and install the extension
# ─────────────────────────────────────────────────────────────────────────
echo "[4/5] Packaging kiosk-guard extension..."

# Check zip is available
if ! command -v zip &>/dev/null; then
  echo "      Installing zip..."
  apk add --no-cache zip
fi

mkdir -p "$EXTENSION_DEST"

# Package the extension as an XPI (XPI is just a ZIP)
cd "$SCRIPT_DIR/extension"
zip -r "$EXTENSION_DEST/kiosk-guard.xpi" manifest.json background.js content.js
chmod 644 "$EXTENSION_DEST/kiosk-guard.xpi"
cd "$SCRIPT_DIR"

echo "      → $EXTENSION_DEST/kiosk-guard.xpi ✔"

# ─────────────────────────────────────────────────────────────────────────
# STEP 5: AppArmor profile
# ─────────────────────────────────────────────────────────────────────────
echo "[5/5] Installing AppArmor profile..."

if ! command -v apparmor_parser &>/dev/null; then
  echo "      AppArmor not installed — installing..."
  apk add --no-cache apparmor apparmor-utils
fi

mkdir -p "$APPARMOR_DIR"
cp "$SCRIPT_DIR/apparmor/usr.bin.firefox" "$APPARMOR_DIR/usr.bin.firefox"
chmod 644 "$APPARMOR_DIR/usr.bin.firefox"

# Load the profile
apparmor_parser -r "$APPARMOR_DIR/usr.bin.firefox"

# Set to enforce mode (blocks violations, does not just log)
aa-enforce "$APPARMOR_DIR/usr.bin.firefox"

# Enable AppArmor on boot
rc-update add apparmor boot 2>/dev/null || true
echo "      → $APPARMOR_DIR/usr.bin.firefox ✔"

# ─────────────────────────────────────────────────────────────────────────
# DONE
# ─────────────────────────────────────────────────────────────────────────
echo ""
echo "══════════════════════════════════════════"
echo " Installation complete."
echo "══════════════════════════════════════════"
echo ""
echo " Files installed:"
echo "   $POLICY_DIR/policies.json"
echo "   $FIREFOX_LIB/defaults/pref/autoconfig.js"
echo "   $FIREFOX_LIB/firefox.cfg"
echo "   $EXTENSION_DEST/kiosk-guard.xpi"
echo "   $APPARMOR_DIR/usr.bin.firefox"
echo ""
echo " Toggle downloads on/off:"
echo "   Edit: $FIREFOX_LIB/firefox.cfg"
echo "   Find the line: lockPref(\"browser.download.forbid_open_with\", true);"
echo "   Comment it out (//) to ENABLE downloads."
echo ""
echo " Change download size limit:"
echo "   Edit: /home/claude/firefox-hardening/extension/background.js"
echo "   Find: const MAX_DOWNLOAD_SIZE_GB = 5;"
echo "   Change the number, then re-run this installer."
echo ""
echo " Reboot the VM to apply all changes."
echo ""
