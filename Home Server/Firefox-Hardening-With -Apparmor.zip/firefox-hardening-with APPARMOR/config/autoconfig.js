// This file tells Firefox to load firefox.cfg as its AutoConfig file.
// Location: /usr/lib/firefox/defaults/pref/autoconfig.js
// Do NOT rename or move this file.

pref("general.config.filename", "firefox.cfg");
pref("general.config.obscure_value", 0);
